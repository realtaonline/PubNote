package com.thaiopensource.datatype.xsd;

class StringDatatype extends TokenDatatype {
  StringDatatype() {
    super(WHITE_SPACE_PRESERVE);
  }
}
